document
  .getElementById("click-upload")
  .addEventListener("click", function (event) {
    event.preventDefault();
    document.getElementById("file-upload").click(); 
  });

  
